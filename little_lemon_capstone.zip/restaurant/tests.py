from datetime import date, time
from django.test import TestCase
from rest_framework.test import APIClient
from .models import MenuItem, Booking

class RestaurantAPITest(TestCase):
    def setUp(self):
        self.client = APIClient()
        MenuItem.objects.create(title="Pasta", price="12.50", inventory=10)

    def test_menu_get(self):
        response = self.client.get("/restaurant/menu/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data), 1)

    def test_menu_post(self):
        response = self.client.post("/restaurant/menu/", {
            "title": "Pizza",
            "price": "15.00",
            "inventory": 5,
        }, format="json")
        self.assertEqual(response.status_code, 201)

    def test_booking_post(self):
        response = self.client.post("/restaurant/booking/", {
            "first_name": "Test User",
            "reservation_date": str(date.today()),
            "reservation_slot": "19:00:00",
        }, format="json")
        self.assertEqual(response.status_code, 201)

    def test_duplicate_booking_is_rejected(self):
        data = {
            "first_name": "Test User",
            "reservation_date": "2026-12-25",
            "reservation_slot": "19:00:00",
        }
        first = self.client.post("/restaurant/booking/", data, format="json")
        second = self.client.post("/restaurant/booking/", data, format="json")
        self.assertEqual(first.status_code, 201)
        self.assertEqual(second.status_code, 400)
