from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import home, MenuItemViewSet, BookingViewSet

router = DefaultRouter()
router.register(r"restaurant/menu", MenuItemViewSet, basename="menu")
router.register(r"restaurant/booking", BookingViewSet, basename="booking")

urlpatterns = [
    path("", home, name="home"),
] + router.urls
